#!/usr/bin/env python
"""
Program from Lisa to Jill to Kurt.  Generate random points on a sphere.

run this command to get help with the command line options:

  ./pointsOnASphere.py --help

Sample run from 300 to 310 points:

  ./pointsOnASphere.py -s 300 -e 310 -b testrun

"""
__version__ = "0.1"
__author__ = 'Bunch of people including Lisa and Kurt'



from math import pi,cos,sin,sqrt
from random import randint
from sys import argv

def makePoints(filename,N=1000):
    """
    Generate N random points on a sphere.  Uses the default python
    random number generator.
    
    filename - file to write out the results to
    N - number of points
    """
    #N=int(argv[1]) # Now from the N parameter passed in.
    out = open (filename,'w')
    nmax,k,npts=5550,66,0
    xn=[0. for i  in range(nmax)]
    yn=[0.  for i in range(nmax)]
    zn=[1.  for i in range(nmax)]
    for  i in range(1,k):
        m = int(2*float(k)*sin(pi*float(i)/float(k)))
        for j in range(m):
            npts=npts+1
            x=sin(pi*float(i)/float(k))*cos(2.*pi*float(j)/float(m))
            y=sin(pi*float(i)/float(k))*sin(2.*pi*float(j)/float(m))
            z=cos(pi*float(i)/float(k))
    # FIX: is there something missing here?  r was indented funny
            r=sqrt(x**2+y**2+z**2)
            xn[npts]=x/r
            yn[npts]=y/r
            zn[npts]=z/r
    for i in range(N):
        pick=randint(0,nmax-1)
        #print xn[pick],yn[pick],zn[pick]
        out.write(str(xn[pick])+' '+str(yn[pick])+' '+str(zn[pick])+'\n')


from optparse import OptionParser

myparser = OptionParser(usage="%prog [options]", version="%prog "+str(__version__))
myparser.add_option('-s','--start',action="store",dest='start',default='10',
                    help='starting N to use [default: %default]',
                    type='int')
myparser.add_option('-e','--end',action="store",dest='end',default='20',
                    help='ending N to use [default: %default]',
                    type='int')

myparser.add_option('-b','--base-filename',action="store",dest='basename',default='points',
                    help='base filename to use when creating output files [default: %default]')


if __name__ == '__main__':
    (options,args) = myparser.parse_args()
    for i in range(options.start,options.end+1):
        filename = str(options.basename) + ("%04d" % i) + ".dat"
        print "Beginning ",i, "      Writing to",filename
        makePoints(filename,i)
