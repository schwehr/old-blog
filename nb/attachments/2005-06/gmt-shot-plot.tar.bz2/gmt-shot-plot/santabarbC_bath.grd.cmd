#! /bin/csh -f
#
# Shellscript to create Postscript plot of data in grd file
# Created by macro mbm_grdplot
#
# This shellscript created by following command line:
# mbm_grdplot -IsantabarbC_bath.grd
#
# Define shell variables used in this script:
set PS_FILE         = santabarbC_bath.grd.ps
set CPT_FILE        = santabarbC_bath.grd.cpt
set MAP_PROJECTION  = m
set MAP_SCALE       = 10.022
#set MAP_REGION      = -120.44/-119.542/34.0894/34.4675
set MAP_REGION      = -120.44/-119.542/34/34.5
set X_OFFSET        = 1
set Y_OFFSET        = 2.2175
#
# Save existing GMT defaults
echo Saving GMT defaults...
gmtdefaults -L > gmtdefaults$$
#
# Set new GMT defaults
echo Setting new GMT defaults...
gmtset MEASURE_UNIT inch
gmtset PAPER_MEDIA archA+
gmtset ANOT_FONT Helvetica
gmtset LABEL_FONT Helvetica
gmtset HEADER_FONT Helvetica
gmtset ANOT_FONT_SIZE 8
gmtset LABEL_FONT_SIZE 8
gmtset HEADER_FONT_SIZE 10
gmtset FRAME_WIDTH 0.075
gmtset TICK_LENGTH 0.075
gmtset PAGE_ORIENTATION LANDSCAPE
gmtset COLOR_BACKGROUND 0/0/0
gmtset COLOR_FOREGROUND 255/255/255
gmtset COLOR_NAN 255/255/255
gmtset DEGREE_FORMAT 3
#
# Make color pallette table file
echo Making color pallette table file...
echo   -625  37  57 175 -562.5  40 127 251 > $CPT_FILE
echo -562.5  40 127 251   -500  50 190 255 >> $CPT_FILE
echo   -500  50 190 255 -437.5 106 235 255 >> $CPT_FILE
echo -437.5 106 235 255   -375 138 236 174 >> $CPT_FILE
echo   -375 138 236 174 -312.5 205 255 162 >> $CPT_FILE
echo -312.5 205 255 162   -250 240 236 121 >> $CPT_FILE
echo   -250 240 236 121 -187.5 255 189  87 >> $CPT_FILE
echo -187.5 255 189  87   -125 255 161  68 >> $CPT_FILE
echo   -125 255 161  68  -62.5 255 186 133 >> $CPT_FILE
echo  -62.5 255 186 133      0 255 255 255 >> $CPT_FILE
#
# Define data files to be plotted:
set DATA_FILE        = santabarbC_bath.grd
set INTENSITY_FILE   = 
#
# Make color image
echo Running grdimage...
#grdimage $DATA_FILE -J$MAP_PROJECTION$MAP_SCALE \
#	-R$MAP_REGION -C$CPT_FILE \
#	-X$X_OFFSET -Y$Y_OFFSET -K -V >! $PS_FILE

#pscoast -Df -W -J$MAP_PROJECTION$MAP_SCALE \
#	-R$MAP_REGION -O -K -V >> $PS_FILE

pscoast -Df -W -J$MAP_PROJECTION$MAP_SCALE \
	-R$MAP_REGION -X$X_OFFSET -Y$Y_OFFSET -K -V >! $PS_FILE


# Fix, how to make these solid the right way?
#-W10/255/0/0
psxy cores.xy -Sc.1c   \
	-G255/0/0 \
        -J$MAP_PROJECTION$MAP_SCALE \
	-R$MAP_REGION \
        -K -O -V >> $PS_FILE

psxy shots.uniq -W1/255/0/255\
        -J$MAP_PROJECTION$MAP_SCALE \
	-R$MAP_REGION \
        -K -O -V >> $PS_FILE

pstext cores.xyt -G0/0/0 \
        -J$MAP_PROJECTION$MAP_SCALE \
	-R$MAP_REGION \
        -K -O -V >> $PS_FILE

pstext tracecounts.pstext -G0/0/0 \
        -J$MAP_PROJECTION$MAP_SCALE \
	-R$MAP_REGION \
        -K -O -V >> $PS_FILE

#-119.95440 39.04235 4 45 1 LM    26000 
#-119.95785 39.04437 4 45 1 LM    27000 

#
# Make color scale
echo Running psscale...
psscale -C$CPT_FILE \
	-D4.5000/-0.5000/9.0000/0.1500h \
	-B":Data Values:" \
	-K -O -V >> $PS_FILE

#
# Make basemap
echo Running psbasemap...
psbasemap -J$MAP_PROJECTION$MAP_SCALE \
	-R$MAP_REGION \
	-B5m/5m:."Data File santabarbC_bath.grd": \
	-O -V >> $PS_FILE

#
# Delete surplus files
echo Deleting surplus files...
/bin/rm -f $CPT_FILE
#
# Reset GMT default fonts
echo Resetting GMT fonts...
/bin/mv gmtdefaults$$ .gmtdefaults
#
# Run ghostview
echo Running ghostview in background...
#ghostview -landscape -media BBox santabarbC_bath.grd.ps &
ps2pdf santabarbC_bath.grd.ps
open santabarbC_bath.grd.pdf
#
# All done!
echo All done!
