Looking back on this code, I have to warn you that the C++ programming
style is not great.  I used macros for TRUE and FALSE, .h on C and C++
headers that should not have them.  This is before I learned doxygen
and gengetopts.

-Kurt 7/2005

----------------------------------------------------------------------

This was inspired by a seminar with J. Gee and S. Cande. We read a
paper simulating mid ocean ridge spreading. This is an attempt to
recreate the process, but use a different data structure. The data
structure is a doubly linked list. Inside the each column in an array
that grows over time as lava flows over the top. The first element in
the array is deepest and new lava is appended on the end of the
array. If the array becomes longer than the current space allocated,
the program reallocs the array with more space. It also is able to
prune things as they move far away from the spreading center. Jeff
estimated a run might take 1/2 hour. I don't know if that was with or
without the magnetics being calculated. This program takes about 20
seconds (PII 333 w/196MB to produce a 6483 x 1435 simulation), but
does not do the magnetics. Most of that time is spent writing the data
to disk.

Idea from "Central anomaly magnetization high: constraints on the
volcanic constructin and architecture of seismic layer 2A at a
fast-spreading mid-ocean ridge, the EPR at 9deg30'-50'N," 1999,
H. Shouten, M. Tivey, D. Fornari, J. Cochran, EPSL 169, p37-50.

Kurt Schwehr -- Feb 2002
