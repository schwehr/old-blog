// $Id: simulation.C,v 1.11 2002/02/18 01:10:50 schwehr Exp schwehr $
// Copyright 2002 Kurt Schwehr - released under the GPL license.
// Kurt Schwehr -- kdschwehr@ucsd.edu

// TODO:
//   Use /dev/random is possible.  Random() is not random.
//   Use a gausian random func instead.

#include <errno.h>
#include <string.h>	// memset
#include <stdlib.h>
#include <assert.h>
#include <iostream.h>
#include <stdio.h>
#ifndef TRUE
#  define TRUE (0==0)
#  define FALSE (1==0)
#endif

#include "simulation.H"

col * new_col (void) {
  col *c;
  c = (col *)malloc(sizeof(col));
  if (!c) {
    fprintf (stderr,"Unable to malloc ram: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  c->botIsDike=FALSE;
  c->length=0;
  c->section_size = 64;  // Initial ram
  c->section = (int *)malloc (c->section_size*sizeof(int));
  if (!c->section) {
    fprintf (stderr,"Unable to malloc ram: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  c->left=NULL;
  c->right=NULL;
  { static int id=0;  c->id=id++; }
  return (c);
}

void delete_col (col *c) {
  assert(c);
  if (!c) return;
  if (c->section) free (c->section);
  free(c);
  return;
}

int MAX(int a,int b) {
  if (a>b) return (a);
  return (b);
}

int max_len (col *c) {
  assert (c);
  int max = -1;
  col *l, *r;
  l = c->left;
  r = c->right;
  while (l) {
    max = MAX(max,l->length);
    l=l->left;
  }
  while (r) {
    max = MAX(max,r->length);
    r=r->right;
  }
  return(max);
}


int ave_len (col *c) {
  assert (c);
  int total = 0;
  int count = 0;
  col *l, *r;
  l = c->left;
  r = c->right;
  while (l) {
    count ++;
    total+=l->length;
    l=l->left;
  }
  l=NULL;
  while (r) {
    count ++;
    total+=r->length;
    r=r->right;
  }
  return(total/count);
}

int check_list (col *c) {
  col *a;
  int count;

  //left
  a = c;
  for (count=0;a && count<10000;count++,a=a->left) {
    int t;
    t = a->id;
  }
  //right
  a = c;
  col *prev;
  for (count=0;a && count<10000;count++) {
    int t;
    t = a->id;
    prev = a;
    a=a->right;
  }
  if (count>=10000) {
    cout << "check_list TOO LONG\n";
    assert(FALSE);
    return (FALSE);
  }
  return (TRUE);
}

// Returning TRUE means we are in big trouble.
int has_loops (col *c) {
  assert(c);
  col *a, *b;
  int count=0;

  a = b = c;
  // go left first;
  while (a && b) {
    count++;
    a = a->left;
    if (b->left) b=b->left->left;
    else break;
    if (b==a) return TRUE;
  }

  count=0;
  a = b = c;
  // go left first;
  while (a && b) {
    a = a->right;
    if (b->right) {
      b=b->right->right;
    }
    else break;
    if (b==a) return TRUE;
  }
  return FALSE;
}

void print_1_col(col *c) {
  if (!c) {cout <<"NULL col\n";return;}
  cout << "------------\n" << "ID = " << c->id << "\n";
  if (c->botIsDike) cout << "Bottom is a dike\n";
  else cout << "NOT dike\n";
  if (c->left) cout << "Left ID = " << c->left->id << "\n";
  else cout << "No left\n";
  if (c->right) cout << "Rght ID = " << c->right->id << "\n";
  else cout << "No rght\n";
  cout << "length = " << c->length << "\n";
  for (int i=c->length;i>0;i--) {
    cout << c->length - i << " is " << c->section[i-1] << "\n";
  }
}

void
print_ids_right(col *c) {
  while (NULL!=c) {
    cout << c->id << " ";
    c = c->right;
  }
  cout << "\n";
}

void
print_ids_right_2(col *c) {
  while (NULL!=c) {
    cout << c->id << " ";
    for (int i=0;i<c->length;i++) {
      cout << c->section[c->length - i - 1] << " ";
    }
    if (c->botIsDike)
      cout << c->section[0] << " "
	   << c->section[0] << " "
	   << c->section[0] << " "
	   << c->section[0];
    c = c->right;
    cout << "\n";
  }
}

col *
get_by_id(col*c, const int id) {
  col *n = get_left_end(c);
  while (NULL != n && id != n->id) {
    n=n->right;
  }
  return n;
}

void
inject (col *c, const int offset, const int length, const int step) {
  assert(c);
  assert(length>=0);
  assert(step>=0);
  //assert (!has_loops(c));

#if 0
  if (c->left && c->right) {
    cout << "Ctr btwn " << c->left->id << " " << c->right->id << "\n";
    print_ids_right(get_left_end(c));
  } else {
    cout << "Starting from empty\n";
  }
#endif

  int i;
  if (NULL==c->left && NULL==c->right) {
    col *l, *r;
    r = new_col();
    l = new_col();
    r->left  = l;
    l->right = r;
    c->right = r;
    c->left  = l;
  }
  assert(c->left);
  assert(c->right);
    
  col *l, *r;
  r = c->right;
  l = c->left;

  assert(!has_loops(c));

  // Step over to the place to insert.
  for (i=0;i<abs(offset);i++) {
    //col *n=0;
    if (0<offset) {
      // go right
      l=r;
      if (!r->right) {
	r->right=new_col();
	r->right->left=r;
      }
      r=r->right;
    } else {
      // go left
      r=l;
      if (!l->left) {
	l->left=new_col();
	l->left->right=l;
      }
      l=l->left;
    }
  }

  assert (!has_loops(c));

  col *r_start, *l_start;
  r_start=r;
  l_start=l;

#if 0
  cout<< "before inserting: lid = " << l->id << " rid = " << r->id << "\n";
  print_ids_right(get_left_end(c));
#endif

  for (i=0;i<length;i++) {
    // Make sure we have enought space for the dike.
    if (r->length==r->section_size-1) {
      r->section_size *=2;
      r->section = (int *)realloc (r->section,r->section_size*sizeof(int));
      if (!r->section) {
	fprintf (stderr,"Unable to realloc ram: %s\n", strerror(errno));
	exit(EXIT_FAILURE);
      }
    }
    if (l->length==l->section_size-1) {
      l->section_size *=2;
      l->section = (int *)realloc (l->section,l->section_size*sizeof(int));
      if (!l->section) {
	fprintf (stderr,"Unable to realloc ram: %s\n", strerror(errno));
	exit(EXIT_FAILURE);
      }
    }
    r->section[r->length]=step;
    l->section[l->length]=step;
    r->length++;
    l->length++;
    if (NULL==l->left) {
      col *n = new_col();
      n->right = l;
      l->left = n;
    }
    l=l->left;
    if (NULL==r->right) {
      col *n = new_col();
      n->left = r;
      r->right = n;
    }
    r=r->right;
  }
  //assert (!has_loops(c));


  col *n = new_col();
  //n->section = (int *)malloc (1024*sizeof(int));
  n->section[0] = step;
  n->length++;
  n->botIsDike = TRUE;

  if (0==offset) {
    // Insert right in the middle
    n->right = c->right;
    n->left = c->left;
    if (c->right) c->right->left = n;
    if (c->left)  c->left->right = n;
    // Alternately choose to push left or right of center
    static int count=0;
    if ( count++ % 2 == 0)
      c->right = n;
    else
      c->left = n;
  } else {
    n->right = r_start;
    n->left  = l_start;
    r_start->left = n;
    l_start->right = n;
  }

  //assert (!has_loops(c));

#if 0
  cout<< "after  inserting: lid = " << l->id << " rid = " << r->id << "\n";
  print_ids_right(get_left_end(c));
#endif

  return;
}

int left_length (col *c) {
  int i=0;
  while (NULL!=c) {i++; c = c->left; }
  return i;
}

int right_length (col *c) {
  int i=0;
  while (NULL!=c) { i++; c = c->right; }
  return i;
}

col *get_left_end(col *c) {
  while (c->left != NULL) c=c->left;
  return c;
}


// Rewrite this to not use buffered IO and to also not allocate a giant buf
// for the whole image.
void save_col(col *c, char *filename) {
  assert (c);
  assert (filename);

  const int MAX_DEPTH = max_len(c) + 10;  // Pad image on bottom
  const int MAX_DIKE_LEN = int(0.75 * MAX_DEPTH); // don't draw a dike longer
  col *l = get_left_end(c);
  const int len = right_length(l);

  cout << "===== Start save_col =======\n";
  cout << "left  len  = " <<  left_length(c->left) << "\n";
  cout << "right len  = " << right_length(c->right) << "\n";
  cout << "total rlen = " << right_length(get_left_end(c)) << "\n";
  cout << "len        = " << len << "\n";
  FILE *img = fopen (filename,"w");
  fprintf (img,"P5\n");
  fprintf (img,"%d %d\n",len, MAX_DEPTH);
  fprintf (img,"255\n");

  cout << "alc Kbytes= " << (sizeof(char)*MAX_DEPTH*len)/1024 << "\n";
  char *buf=(char *)malloc(sizeof(char)*MAX_DEPTH*len);
  if (!buf) {
    fprintf (stderr,"Unable to realloc ram: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  memset(buf,0,MAX_DEPTH*len);

  int i;
  col *next = l;

  for (i=0; i<len; i++, next = next->right) {
    if (i%50 == 0) fprintf (stderr,"\r%d",i);
    assert (next);
    int x = i;
    for (int offset=next->length -1;offset>=0;offset--) {
      int y = (next->length-1) - offset;
      buf[y*len + x] = (unsigned char)next->section[offset];
    }
    if (/*0==offset && */next->botIsDike) {
      int y;
      unsigned char value = (unsigned char)next->section[0];
      for (y=(next->length-1);y<MAX_DEPTH&&(y-next->length<MAX_DIKE_LEN);y++) {
	buf[y*len +x] =value;
      }
    }
  }
  fprintf (stderr,"\nWriting data to file\n");

  fwrite (buf,MAX_DEPTH*len,sizeof(char),img);
}
// Returns the number of cols freed
int
clean_distant_cols(col *center,const int max_dist) {
  col *n,*cur=NULL;  // next node
  int total=0;
  int count;

  // LEFT
  for (count=0,n=center;n!=NULL&&count < max_dist;count++,n=n->left);
  if (n) {
    cur=n;
    n=cur->left;
    cur->left=NULL;
    cur=n;
  }
  while (cur) {
    n=cur->left;
    delete_col(cur);
    cur=n;
    total++;
  }

  // RIGHT
  for (count=0,n=center;n!=NULL&&count < max_dist;count++,n=n->right);
  if (n) {
    cur=n;
    n=cur->right;
    cur->right=NULL;
    cur=n;
  }
  while (cur) {
    n=cur->right;
    delete_col(cur);
    cur=n;
    total++;
  }
  return(total);
}

int main (int argc, char *argv[]) {
  col *center;
  center = new_col();
  center->botIsDike=-666;
  center->length=-666;

  int i;
  for (i=0;i<5000;i++) {
    if (i%50 == 0) fprintf (stderr,"\r%d",i);
    static int volcanic_zone = 50;
    static int flow_width = 500;
    int offset = rand() % volcanic_zone - volcanic_zone/2;
    int width = rand() % flow_width + flow_width/2;
    //cout << "\n\n--------------\noffset = " << offset << "\n";
    inject (center, offset, width, i+1);
    //char filename[256];
    //sprintf (filename, "tmp%02d.ppm",i); save_col(center,filename);
    if (i%200 == 0) {
      int removed = clean_distant_cols(center,4000);
      if (removed) cout << " Removed cols: " << removed; // << "\n";
    }
  }
  fprintf (stderr,"\n");

  //col *tmp = get_left_end(center);
  //print_ids_right_2(tmp);

  cout << "MAX depth to top of dike = " << max_len(center) << "\n";
  cout << "AVE depth to top of dike = " << ave_len(center) << "\n";

  save_col(center, "final.ppm");
  return (EXIT_SUCCESS);
}
